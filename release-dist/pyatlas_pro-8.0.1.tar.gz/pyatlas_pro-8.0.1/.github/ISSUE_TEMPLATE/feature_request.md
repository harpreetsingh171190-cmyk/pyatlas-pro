---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

**Problem you want solved**

**Proposed behaviour**

**Alternatives considered**
