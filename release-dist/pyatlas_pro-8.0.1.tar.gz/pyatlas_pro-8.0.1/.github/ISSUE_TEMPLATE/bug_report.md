---
name: Bug report
about: Something does not work as documented
labels: bug
---

**What happened**

**What you expected**

**Steps to reproduce**

**Environment** (PyAtlas version, OS, Python version, browser)

Do not paste private notes, backups or passwords.
