## What changed

## Checks completed

- [ ] `python -m unittest discover -s tests -v`
- [ ] `npm test`
- [ ] `python -m pyatlas validate` and `python -m pyatlas build --output dist`
- [ ] Docs and CHANGELOG updated where behaviour changed
- [ ] No secrets, personal data or machine-specific paths
